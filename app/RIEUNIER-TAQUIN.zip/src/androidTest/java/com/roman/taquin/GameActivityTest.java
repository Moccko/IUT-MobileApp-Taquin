package com.roman.taquin;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by roman on 10/03/17.
 */
public class GameActivityTest {
    @Test
    public void onCreate() throws Exception {

    }

    @Test
    public void move() throws Exception {
    }

}